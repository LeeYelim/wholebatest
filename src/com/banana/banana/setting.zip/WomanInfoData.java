package com.banana.banana.setting;

public class WomanInfoData {
	public String period_no;
	public String period_start;
	public String period_end;
	public int period_cycle;
}
